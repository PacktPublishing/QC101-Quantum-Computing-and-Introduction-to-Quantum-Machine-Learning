public class ClassicalPhoton 
{
    public double polarizationAngle = 90;
}
