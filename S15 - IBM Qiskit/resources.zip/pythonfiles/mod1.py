def module1Function():
    print("This function is in module 1")
    
print("Module 1 has been loaded")