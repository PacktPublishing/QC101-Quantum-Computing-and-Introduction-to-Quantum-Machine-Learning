def module2Function():
    print("This function is in module 2")
    
print("Module 2 has been loaded")