#Decisions

if(1 == 1):
    print("yes it is")
    print("true")
else:
    print("That can't be!")
    
if(1==2):
    print("Nope")
elif(1==1):
    print("Yup")
else:
    pass