#Functions

myFriends = ["John", "Jack", "Alice", "Bob"]

def printList(listVar):
    for item in listVar:
        print(item)
        
printList(myFriends)