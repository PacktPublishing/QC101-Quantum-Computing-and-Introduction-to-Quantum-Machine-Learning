#Operators

print(3 + 2 - 1*4)

print(4/2) # Division always produces a floating point number

print(10 % 3) #remainder of division

print(2 ** 8) #2 raised to the power of 8