#Strings

print("Hello " + 'World')

helloWorld = "Hello World"

print(helloWorld[3:5])

print(helloWorld[-5:])

print("bye" in helloWorld)

print("ell" in helloWorld)