#Modules

import mod1 as m1

m1.module1Function()


from mod2 import module2Function

module2Function()