#Object types

print(type(11))

print(type("Hello World"))

print(type(1.2))

print(type( [1, 2, "How are you?"] ))

print( type( str(10) ))

print( "A very large integer with full precision:",123456789012345678901234567890)

print(True, False)