#Conversions

print(int(2.345))

print(float(10))